from tkinter import *
from tkinter import messagebox

from ChangePassword import ChangePasswordClass
from DepartmentPage import DepartmentClass
from ManageUser import UserClass
from Report1page import Report1Class
from Report2page import Report2Class
from Report3page import Report3Class
from Studentpage import StudentClass
from coursePage import CourseClass


class HomepageClass:
    def __init__(self,uname,utype):
        self.uname=uname
        self.utype=utype
        self.window=Tk()

        # -------------settings ----------------------------
        self.window.title("College Manager")
        w= self.window.winfo_screenwidth()
        h= self.window.winfo_screenheight()
        w1 = int(w/2)
        h1 = int(h/2 )
        x1 = int(w/2 - w/4)
        y1 = int(h/2 - h/4)

        self.window.minsize(w1,h1)
        self.window.geometry("%dx%d+%d+%d"%(w1,h1,x1,y1))  # width,height,x,y
        self.window.state('zoomed')

        # ----------- background image---------------------------------
        from PIL import Image,ImageTk
        self.bkimg1 = Image.open("app_images//collegebg1.jpg").resize((w,h))  # open image and resize
        self.bkimg2 = ImageTk.PhotoImage(self.bkimg1) # open as photoimage
        self.bklbl = Label(self.window,image=self.bkimg2)
        self.bklbl.place(x=0,y=0,width=w,height=h)


        # ---------------- menus ---------------------------------------
        self.window.option_add('*TearOff',False)
        self.menubar=Menu(self.window)
        self.window.config(menu=self.menubar)

        self.menu1 = Menu(self.menubar)
        self.menu2 = Menu(self.menubar)
        self.menu3 = Menu(self.menubar)
        self.menu4 = Menu(self.menubar)

        self.menubar.add_cascade(menu=self.menu1,label="Manage")
        self.menubar.add_cascade(menu=self.menu2,label="Department")
        self.menubar.add_cascade(menu=self.menu3,label="Reports")
        self.menubar.add_cascade(menu=self.menu4,label="Account")

        # self.menu1.add_command(label='Student',command=lambda : StudentClass())  # to open independent window
        self.menu1.add_command(label='Student',command=lambda : StudentClass(self.window))  # to open dependent window
        self.menu1.add_command(label='Teacher')

        self.menu2.add_command(label='Department',command=lambda : DepartmentClass(self.window),accelerator="ctrl+d")
        self.window.bind("<Control-d>",lambda e: DepartmentClass(self.window))

        self.menu2.add_command(label='Course',command=lambda : CourseClass(self.window))

        self.menu3.add_command(label='All Student',command=lambda : Report1Class(self.window))
        self.menu3.add_command(label='Student By Department',command=lambda : Report2Class(self.window))
        self.menu3.add_command(label='Student By DOB',command=lambda : Report3Class(self.window))

        self.iconimg1 = Image.open("app_images//bg1.png").resize((20,20))  # open image and resize
        self.iconimgp1 = ImageTk.PhotoImage(self.iconimg1)
        self.menu4.add_command(label='User',command=lambda : UserClass(self.window),image=self.iconimgp1,compound=TOP)

        self.iconimg2 = Image.open("app_images//bg2.png").resize((20,20))  # open image and resize
        self.iconimgp2 = ImageTk.PhotoImage(self.iconimg2)
        self.menu4.add_command(label='Change Password',command=lambda : ChangePasswordClass(self.window,self.uname),
                               image=self.iconimgp2,compound=LEFT)
        self.menu4.add_command(label='Logout',command=self.quitter)


        if self.utype=="Employee":
            self.menubar.entryconfig(1,state='disable')
            self.menubar.delete(0)

            self.menu3.entryconfig(0,state='disable')
            self.menu4.delete(0)

        self.window.mainloop()

    def quitter(self):
        ans = messagebox.askquestion("Confirmation","Are you to Logout?",parent=self.window)
        if ans=='yes':
            self.window.destroy()
            from LoginPage import LoginClass
            LoginClass()
