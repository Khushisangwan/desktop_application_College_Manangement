from tkinter import *
from tkinter import messagebox
from tkinter.filedialog import askopenfilename
from tkinter.ttk import Combobox, Treeview
from tkcalendar import DateEntry
from PIL import Image,ImageTk
import pymysql
class StudentClass:
    default_image="default_image2.png"
    def __init__(self,home_window):
        # self.window = Tk() # to create independent window
        # self.window = home_window  # now homepage(home_window) and self.window(studentPage) is same
        self.window = Toplevel(home_window)  # self.window(studentpage) will acts as child to home_window(homepage)

        # -------------settings ----------------------------
        self.window.title("College Manager")
        w= self.window.winfo_screenwidth()
        h= self.window.winfo_screenheight()
        w1 = int(w-100)
        h1 = int(h-180)

        self.window.minsize(w1,h1)
        self.window.geometry("%dx%d+%d+%d"%(w1,h1,50,70))
        self.window.title("College Manager/Student")
        # --------------------- widgets -----------------------------------------------


        mycolor='#FFC5C5'
        mycolor2='#E30000'
        myfont1=("Trebuchet MS",15)

        self.window.config(background=mycolor)

        self.hdlbl = Label(self.window,text="Student",background=mycolor2,
                           font=("Georgia",35,'bold'),relief='groove',borderwidth=10,foreground='white')
        self.L1 = Label(self.window,text="Roll no",background=mycolor,font=myfont1)
        self.L2 = Label(self.window,text="Name",background=mycolor,font=myfont1)
        self.L3 = Label(self.window,text="Phone",background=mycolor,font=myfont1)
        self.L4 = Label(self.window,text="Gender",background=mycolor,font=myfont1)
        self.L5 = Label(self.window,text="DOB",background=mycolor,font=myfont1)
        self.L6 = Label(self.window,text="Address",background=mycolor,font=myfont1)
        self.L7 = Label(self.window,text="Department",background=mycolor,font=myfont1)
        self.L8 = Label(self.window,text="Course",background=mycolor,font=myfont1)

        self.t1 = Entry(self.window,font=myfont1)
        self.t2 = Entry(self.window,font=myfont1)
        self.t3 = Entry(self.window,font=myfont1)
        self.v1=StringVar()
        self.r1 = Radiobutton(self.window,value='Male',text="Male",
                              variable=self.v1,background=mycolor,font=myfont1)
        self.r2 = Radiobutton(self.window,value='Female',text="Female",
                              variable=self.v1,background=mycolor,font=myfont1)
        self.t5 = DateEntry(self.window, width=12, background='darkblue', foreground='white',
                            borderwidth=2, year=2010,font=myfont1,date_pattern='y-mm-dd')
        self.t6 = Text(self.window,font=myfont1,width=20,height=3)
        self.v2=StringVar()
        self.c1=Combobox(self.window,textvariable=self.v2,state='readonly',font=myfont1)
        self.c1.bind("<<ComboboxSelected>>",lambda e: self.getAllCourses())
        self.v3=StringVar()
        self.c2=Combobox(self.window,textvariable=self.v3,state='readonly',font=myfont1)

        #---------------- table -------------

        self.mytable = Treeview(self.window,columns=['c1','c2','c3','c4','c5','c6','c7','c8'],height=10)
        self.mytable.heading('c1',text='Roll no')
        self.mytable.heading('c2',text='Name')
        self.mytable.heading('c3',text='Phone')
        self.mytable.heading('c4',text='gender')
        self.mytable.heading('c5',text='DOB')
        self.mytable.heading('c6',text='Address')
        self.mytable.heading('c7',text='Department')
        self.mytable.heading('c8',text='Course')

        self.mytable['show']='headings'

        self.mytable.column("#1",width=100,anchor='center')
        self.mytable.column("#2",width=100,anchor='center')
        self.mytable.column("#3",width=100,anchor='center')
        self.mytable.column("#4",width=100,anchor='center')
        self.mytable.column("#5",width=100,anchor='center')
        self.mytable.column("#6",width=100,anchor='center')
        self.mytable.column("#7",width=100,anchor='center')
        self.mytable.column("#8",width=100,anchor='center')
        self.mytable.bind("<ButtonRelease-1>",lambda e: self.getSelectedRowData())

        #-------------- buttons -----------------------------------------------

        self.b1 = Button(self.window,text="Save",background=mycolor2,foreground='white',font=myfont1,command=self.saveData)
        self.b2 = Button(self.window,text="Update",background=mycolor2,foreground='white',font=myfont1,command=self.updateData)
        self.b3 = Button(self.window,text="Delete",background=mycolor2,foreground='white',font=myfont1,command=self.deleteData)
        self.b4 = Button(self.window,text="Fetch",background=mycolor2,foreground='white',font=myfont1,command=self.fetchData)
        self.b5 = Button(self.window,text="Search",background=mycolor2,foreground='white',font=myfont1,command=self.getAllData)
        self.b6 = Button(self.window,text="Upload",background=mycolor2,foreground='white',font=myfont1,command=self.selectImage)

        self.imglbl = Label(self.window,relief="ridge",borderwidth=2)

        #-------------- placements -----------------------------------------------
        self.hdlbl.place(x=0,y=0,width=w1,height=80)
        x1 = 20
        y1 = 100

        x_diff=150
        y_diff=50

        self.L1.place(x=x1,y=y1)
        self.t1.place(x=x1+x_diff,y=y1)
        self.b4.place(x=x1+x_diff+x_diff+60,y=y1,width=100,height=30)
        self.mytable.place(x=x1+x_diff+x_diff+200,y=y1)

        y1+=y_diff
        self.L2.place(x=x1,y=y1)
        self.t2.place(x=x1+x_diff,y=y1)
        self.b5.place(x=x1+x_diff+x_diff+60,y=y1,width=100,height=30)
        y1+=y_diff
        self.L3.place(x=x1,y=y1)
        self.t3.place(x=x1+x_diff,y=y1)
        y1+=y_diff
        self.L4.place(x=x1,y=y1)
        self.r1.place(x=x1+x_diff,y=y1)
        self.r2.place(x=x1+x_diff+x_diff,y=y1)
        y1+=y_diff
        self.L5.place(x=x1,y=y1)
        self.t5.place(x=x1+x_diff,y=y1)
        y1+=y_diff
        self.L6.place(x=x1,y=y1)
        self.t6.place(x=x1+x_diff,y=y1)
        y1+=y_diff
        y1+=y_diff
        self.L7.place(x=x1,y=y1)
        self.c1.place(x=x1+x_diff,y=y1)
        y1+=y_diff
        self.L8.place(x=x1,y=y1)
        self.c2.place(x=x1+x_diff,y=y1)
        y1+=y_diff
        self.b1.place(x=x1,y=y1,width=100,height=40)
        self.b2.place(x=x1+x_diff+10,y=y1,width=100,height=40)
        self.b3.place(x=x1+x_diff+x_diff+20,y=y1,width=100,height=40)


        self.imglbl.place(x=x1+500,y=y1-150,width=150,height=150)
        self.b6.place(x=x1+500,y=y1,width=150,height=40)

        self.databaseConnection()
        self.clearPage()
        self.getAllDepartment()
        self.window.mainloop()

    def selectImage(self):
        self.filename = askopenfilename(file=[  ("All Pictures","*.png;*.jpg;*.jpeg") ,
                                                ('PNG Images',"*.png"),('JPG Images',"*.jpg")])
        print("filename = ",self.filename)

        self.img1 = Image.open(self.filename).resize((150,150))  # open image and resize
        self.img2 = ImageTk.PhotoImage(self.img1) # open as photoimage
        self.imglbl.config(image=self.img2) # add photoimage in label

        path = self.filename.split("/")
        # print("path = ",path)
        name = path[-1]
        # print("name = ",name)
        import time
        uniquness = str(int(time.time()))
        # print("uniquenss  = ",uniquness)
        self.actualname = uniquness+name
        # print("actual name = ",self.actualname)


    def databaseConnection(self):
        try:
            self.conn = pymysql.connect(host="localhost",db="college_manager_db",user="root",password="")
            self.curr = self.conn.cursor()
        except Exception as e:
            messagebox.showinfo("Database Error","Database Connection Error : \n"+str(e),parent=self.window)

    def saveData(self):
        if self.validate_check()==False:
            return # stop function now

        if self.actualname==self.default_image: # no image is selected
            # nothing to save in folder
            pass
        else: # image is selected
            self.img1.save("student_images//"+self.actualname)


        #rollno	name	phone	gender	dob	address	department	course
        try:
            qry = "insert into student_table values(%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            rowcount = self.curr.execute(qry,(self.t1.get(), self.t2.get(),self.t3.get(),self.v1.get(),
                                   self.t5.get_date(),self.t6.get('1.0',END),self.v2.get(),self.v3.get(),
                                              self.actualname))
            self.conn.commit()
            if rowcount==1:
                messagebox.showinfo("Sucess","Student Added successfully :)",parent=self.window)
                self.clearPage()
        except Exception as e:
            messagebox.showerror("Query Error", "Query Error : \n" + str(e), parent=self.window)

    def updateData(self):
        if self.validate_check()==False:
            return # stop function now

        if self.actualname==self.oldname: # no new image is selected
            # nothing to delete or save
            pass
        else:  # new image is selected
            self.img1.save("student_images//"+self.actualname)
            if self.oldname==self.default_image: # no image was given
                # nothing to delete
                pass
            else:
                import os
                os.remove("student_images//"+self.oldname)


        try:
            qry = "update student_table set name=%s, phone=%s, gender=%s, dob=%s, address=%s, " \
                  "department=%s, course=%s, pic=%s where rollno=%s "
            rowcount = self.curr.execute(qry,(self.t2.get(),self.t3.get(),self.v1.get(),
                                   self.t5.get_date(),self.t6.get('1.0',END),self.v2.get(),self.v3.get(),
                                              self.actualname,self.t1.get()))
            self.conn.commit()
            if rowcount==1:
                messagebox.showinfo("Sucess","Student Update successfully :)",parent=self.window)
                self.clearPage()
        except Exception as e:
            messagebox.showerror("Query Error", "Query Error : \n" + str(e), parent=self.window)

    def deleteData(self):
        #rollno	name	phone	gender	dob	address	department	course

        ans = messagebox.askquestion("Confirmation","Are you to delete?",parent=self.window)
        if ans=='yes':

            if self.oldname==self.default_image: # no image was given
                # nothing to delete
                pass
            else:
                import os
                os.remove("student_images//"+self.oldname)

            try:
                qry = "delete from student_table where rollno=%s "
                rowcount = self.curr.execute(qry,(self.t1.get()))
                self.conn.commit()
                if rowcount==1:
                    messagebox.showinfo("Sucess","Student deleted successfully :)",parent=self.window)
                    self.clearPage()
            except Exception as e:
                messagebox.showerror("Query Error", "Query Error : \n" + str(e), parent=self.window)

    def getSelectedRowData(self):
        row_id = self.mytable.focus()
        print("Row id = ",row_id)
        rowdata = self.mytable.item(row_id)
        print("Row Data = ",rowdata)
        row_values = rowdata['values']
        print("Row Values = ",row_values)
        cols_data = row_values[0]
        print("Column 0 data = ",cols_data)
        self.fetchData(cols_data)

    def fetchData(self,pk_col=None):
        if pk_col==None:
            rollno = self.t1.get()
        else:
            rollno=pk_col
        try:
            qry = "select * from student_table where rollno=%s"
            rowcount = self.curr.execute(qry,(rollno))
            data = self.curr.fetchone()
            # print("data = ",data)
            self.clearPage()
            if data:
                self.t1.insert(0,data[0])
                self.t2.insert(0,data[1])
                self.t3.insert(0,data[2])
                self.v1.set(data[3])
                self.t5.set_date(data[4])
                self.t6.insert('1.0',data[5])
                self.v2.set(data[6])
                self.v3.set(data[7])
                self.actualname=data[8]
                self.oldname=data[8]

                self.img1 = Image.open("student_images//"+self.actualname).resize((150,150))  # open image and resize
                self.img2 = ImageTk.PhotoImage(self.img1) # open as photoimage
                self.imglbl.config(image=self.img2) # add photoimage in label




            else:
                messagebox.showwarning("Empty", "No Record Found", parent=self.window)

        except Exception as e:
            messagebox.showerror("Query Error", "Query Error : \n" + str(e), parent=self.window)

    def clearPage(self):
        self.t1.delete(0,END)
        self.t2.delete(0,END)
        self.t3.delete(0,END)
        self.v1.set(None)
        self.t5.delete(0,END)
        self.t6.delete('1.0',END)
        self.v2.set("Choose Department")
        self.v3.set("Choose Course")
        self.actualname=self.default_image

        self.img1 = Image.open("student_images//"+self.actualname).resize((150,150))  # open image and resize
        self.img2 = ImageTk.PhotoImage(self.img1) # open as photoimage
        self.imglbl.config(image=self.img2) # add photoimage in label


    def getAllData(self):
        try:
            self.mytable.delete(*self.mytable.get_children())

            qry = "select * from student_table where name like %s "
            rowcount = self.curr.execute(qry,(self.t2.get()+"%"))
            data = self.curr.fetchall()
            # print("data = \n",data)
            if data:
                for myrow in data:
                    self.mytable.insert("",END,values=myrow)

            else:
                messagebox.showwarning("Empty", "No Record Found", parent=self.window)

        except Exception as e:
            messagebox.showerror("Query Error", "Query Error : \n" + str(e), parent=self.window)

    def validate_check(self):
        if not(self.t1.get().isdigit())  or len(self.t1.get())<1:
            messagebox.showwarning("Validation Check", "Invalid Roll no", parent=self.window)
            return False
        elif len(self.t2.get())<2:
            messagebox.showwarning("Validation Check", "Enter proper name (atleast 2 characters) ", parent=self.window)
            return False
        elif not(self.t3.get().isdigit())   or  len(self.t3.get())!=10:
            messagebox.showwarning("Validation Check", "Enter valid phone no \n10 digits only", parent=self.window)
            return False
        elif not (self.v1.get() == 'Male' or self.v1.get() == 'Female'):
            messagebox.showwarning("Input Error", "Please Select gender ", parent=self.window)
            return False
        elif (self.t5.get() == ""):
            messagebox.showwarning("Input Error", "Please Select DOB ", parent=self.window)
            return False
        elif len(self.t6.get('1.0', END)) < 3:
            messagebox.showwarning("Input Error", "Please Enter Address ", parent=self.window)
            return False

        elif (self.v2.get() == "Choose Department")or (self.v2.get() == "No Department"):
            messagebox.showwarning("Input Error", "Please Select Department ", parent=self.window)
            return False

        elif (self.v3.get() == "Choose Course") or (self.v3.get() == "No Course"):
            messagebox.showwarning("Input Error", "Please Select Course ", parent=self.window)
            return False
        return  True

    def getAllDepartment(self):
        try:
            qry = "select * from department  "
            rowcount = self.curr.execute(qry)
            data = self.curr.fetchall()
            self.deptList=[]
            if data:
                self.c1.set("Choose Department")
                for myrow in data:
                    self.deptList.append(myrow[0])
            else:
                self.c1.set("No Department")

            self.c1.config(values=self.deptList)

        except Exception as e:
            messagebox.showerror("Query Error", "Query Error : \n" + str(e), parent=self.window)

    def getAllCourses(self):
        try:
            qry = "select * from course where dname=%s"
            rowcount = self.curr.execute(qry,(self.v2.get()))
            data = self.curr.fetchall()
            self.courseList=[]
            if data:
                self.c2.set("Choose Course")
                for myrow in data:
                    self.courseList.append(myrow[1])
            else:
                self.c2.set("No Course")

            self.c2.config(values=self.courseList)

        except Exception as e:
            messagebox.showerror("Query Error", "Query Error : \n" + str(e), parent=self.window)



if __name__ == '__main__':
    dummy_homepage = Tk()
    StudentClass(dummy_homepage)
    dummy_homepage.mainloop()