from tkinter import *
from tkinter import messagebox
from tkinter.ttk import Combobox, Treeview
import pymysql
class CourseClass:
    def __init__(self,home_window):
        self.window = Toplevel(home_window)
        # -------------settings ----------------------------
        self.window.title("College Manager")
        w= self.window.winfo_screenwidth()
        h= self.window.winfo_screenheight()
        w1 = int(w-100)
        h1 = int(h-180)

        self.window.minsize(w1,h1)
        self.window.geometry("%dx%d+%d+%d"%(w1,h1,50,70))
        self.window.title("College Manager/Course")
        # --------------------- widgets -----------------------------------------------

        mycolor='#FFC5C5'
        mycolor2='#E30000'
        myfont1=("Trebuchet MS",15)

        self.window.config(background=mycolor)

        self.hdlbl = Label(self.window,text="Course",background=mycolor2,
                           font=("Georgia",35,'bold'),relief='groove',borderwidth=10,foreground='white')
        self.L1 = Label(self.window,text="Department",background=mycolor,font=myfont1)
        self.L2 = Label(self.window,text="Course ",background=mycolor,font=myfont1)
        self.L3 = Label(self.window,text="Duration",background=mycolor,font=myfont1)
        self.L4 = Label(self.window,text="Fee",background=mycolor,font=myfont1)

        self.v1=StringVar()
        self.c1=Combobox(self.window,values=("IT","Commerce"),textvariable=self.v1,
                         state='readonly',font=myfont1)
        self.t2 = Entry(self.window,font=myfont1)
        self.t3 = Entry(self.window,font=myfont1)
        self.t4 = Entry(self.window,font=myfont1)

        #---------------- table -------------

        self.mytable = Treeview(self.window,columns=['c1','c2','c3','c4'],height=20)
        self.mytable.heading('c1',text='Department')
        self.mytable.heading('c2',text='Course')
        self.mytable.heading('c3',text='Duration')
        self.mytable.heading('c4',text='Fee')

        self.mytable['show']='headings'

        self.mytable.column("#1",width=150,anchor='center')
        self.mytable.column("#2",width=150,anchor='center')
        self.mytable.column("#3",width=150,anchor='center')
        self.mytable.column("#4",width=150,anchor='center')
        self.mytable.bind("<ButtonRelease-1>",lambda e: self.getSelectedRowData())

        #-------------- buttons -----------------------------------------------

        self.b1 = Button(self.window,text="Save",background=mycolor2,foreground='white',font=myfont1,command=self.saveData)
        self.b2 = Button(self.window,text="Update",background=mycolor2,foreground='white',font=myfont1,command=self.updateData)
        self.b3 = Button(self.window,text="Delete",background=mycolor2,foreground='white',font=myfont1,command=self.deleteData)
        self.b4 = Button(self.window,text="Fetch",background=mycolor2,foreground='white',font=myfont1,command=self.fetchData)
        self.b5 = Button(self.window,text="Search",background=mycolor2,foreground='white',font=myfont1,command=self.getAllData)

        #-------------- placements -----------------------------------------------
        self.hdlbl.place(x=0,y=0,width=w1,height=80)
        x1 = 20
        y1 = 100

        x_diff=150
        y_diff=50

        self.L1.place(x=x1,y=y1)
        self.c1.place(x=x1+x_diff,y=y1)
        self.b5.place(x=x1+x_diff+x_diff+60,y=y1,width=100,height=30)
        self.mytable.place(x=x1+x_diff+x_diff+200,y=y1)

        y1+=y_diff
        self.L2.place(x=x1,y=y1)
        self.t2.place(x=x1+x_diff,y=y1)
        self.b4.place(x=x1+x_diff+x_diff+60,y=y1,width=100,height=30)
        y1+=y_diff
        self.L3.place(x=x1,y=y1)
        self.t3.place(x=x1+x_diff,y=y1)
        y1+=y_diff
        self.L4.place(x=x1,y=y1)
        self.t4.place(x=x1+x_diff,y=y1)

        y1+=y_diff
        self.b1.place(x=x1,y=y1,width=100,height=40)
        self.b2.place(x=x1+x_diff+10,y=y1,width=100,height=40)
        self.b3.place(x=x1+x_diff+x_diff+20,y=y1,width=100,height=40)



        self.databaseConnection()
        self.clearPage()
        self.getAllDepartment()
        self.window.mainloop()

    def databaseConnection(self):
        try:
            self.conn = pymysql.connect(host="localhost",db="college_manager_db",user="root",password="")
            self.curr = self.conn.cursor()
        except Exception as e:
            messagebox.showinfo("Database Error","Database Connection Error : \n"+str(e),parent=self.window)

    def saveData(self):
        if self.validate_check()==False:
            return
        try:
            qry = "insert into course values(%s,%s,%s,%s)"
            rowcount = self.curr.execute(qry,(self.v1.get(), self.t2.get(),self.t3.get(),self.t4.get()))
            self.conn.commit()
            if rowcount==1:
                messagebox.showinfo("Sucess","Course Added successfully :)",parent=self.window)
                self.clearPage()
        except Exception as e:
            messagebox.showerror("Query Error", "Query Error : \n" + str(e), parent=self.window)

    def updateData(self):
        if self.validate_check()==False:
            return
        try:
            qry = "update course set dname=%s, duration=%s, fee=%s  where cname=%s "
            rowcount = self.curr.execute(qry,(self.v1.get(), self.t3.get(),self.t4.get(),self.t2.get()))
            self.conn.commit()
            if rowcount==1:
                messagebox.showinfo("Sucess","Course Updated successfully :)",parent=self.window)
                self.clearPage()
        except Exception as e:
            messagebox.showerror("Query Error", "Query Error : \n" + str(e), parent=self.window)

    def deleteData(self):
        ans = messagebox.askquestion("Confirmation","Are you to delete?",parent=self.window)
        if ans=='yes':
            try:
                qry = "delete from course where cname=%s "
                rowcount = self.curr.execute(qry,(self.t2.get()))
                self.conn.commit()
                if rowcount==1:
                    messagebox.showinfo("Sucess","Course deleted successfully :)",parent=self.window)
                    self.clearPage()
            except Exception as e:
                messagebox.showerror("Query Error", "Query Error : \n" + str(e), parent=self.window)

    def getSelectedRowData(self):
        row_id = self.mytable.focus()
        rowdata = self.mytable.item(row_id)
        row_values = rowdata['values']
        cols_data = row_values[1]
        self.fetchData(cols_data)

    def fetchData(self,pk_col=None):
        if pk_col==None:
            course_name = self.t2.get()
        else:
            course_name=pk_col
        try:
            qry = "select * from course where cname=%s"
            rowcount = self.curr.execute(qry,(course_name))
            data = self.curr.fetchone()
            self.clearPage()
            if data:
                self.v1.set(data[0])
                self.t2.insert(0,data[1])
                self.t3.insert(0,data[2])
                self.t4.insert(0,data[3])

            else:
                messagebox.showwarning("Empty", "No Record Found", parent=self.window)

        except Exception as e:
            messagebox.showerror("Query Error", "Query Error : \n" + str(e), parent=self.window)

    def clearPage(self):
        self.v1.set("Choose Department")
        self.t2.delete(0,END)
        self.t3.delete(0,END)
        self.t4.delete(0,END)

    def getAllData(self):
        try:
            self.mytable.delete(*self.mytable.get_children())

            qry = "select * from course where dname like %s "
            rowcount = self.curr.execute(qry,(self.v1.get()+"%"))
            data = self.curr.fetchall()
            # print("data = \n",data)

            if data:
                for myrow in data:
                    self.mytable.insert("",END,values=myrow)

            else:
                messagebox.showwarning("Empty", "No Record Found", parent=self.window)

        except Exception as e:
            messagebox.showerror("Query Error", "Query Error : \n" + str(e), parent=self.window)


    def validate_check(self):
        if (self.v1.get() == "Choose Department")or (self.v1.get() == "No Department"):
            messagebox.showwarning("Input Error", "Please Select Department ", parent=self.window)
            return False
        elif len(self.t2.get())<1:
            messagebox.showwarning("Validation Check", "Enter Course Name", parent=self.window)
            return False
        elif len(self.t3.get())<1:
            messagebox.showwarning("Validation Check", "Enter Duration", parent=self.window)
            return False
        elif len(self.t4.get())<1:
            messagebox.showwarning("Validation Check", "Enter Fee", parent=self.window)
            return False
        return True

    def getAllDepartment(self):
        try:
            qry = "select * from department  "
            rowcount = self.curr.execute(qry)
            data = self.curr.fetchall()
            self.deptList=[]
            if data:
                self.c1.set("Choose Department")
                for myrow in data:
                    self.deptList.append(myrow[0])
            else:
                self.c1.set("No Department")

            self.c1.config(values=self.deptList)

        except Exception as e:
            messagebox.showerror("Query Error", "Query Error : \n" + str(e), parent=self.window)



if __name__ == '__main__':
    dummy_homepage = Tk()
    CourseClass(dummy_homepage)
    dummy_homepage.mainloop()